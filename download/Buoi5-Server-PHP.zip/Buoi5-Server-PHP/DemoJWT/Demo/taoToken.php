<?php
require("jwt.php");

$token = array();
$token["id"] = 7777;
$token["hoten"] = "Nguyen Van Teo";
$token["email"] = "teo@khoapham.vn";

$jsonwebtoken = JWT::encode($token, "DUNG_CHO_AI_BIET_NHA");
echo JsonHelper::getJson("token", $jsonwebtoken);
?>
