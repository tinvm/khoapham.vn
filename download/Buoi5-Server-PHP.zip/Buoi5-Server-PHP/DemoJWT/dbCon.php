<?php
mysql_connect("localhost", "root", "");
mysql_select_db("DemoJWT");
mysql_query("SET NAMES 'utf8'");
?>
