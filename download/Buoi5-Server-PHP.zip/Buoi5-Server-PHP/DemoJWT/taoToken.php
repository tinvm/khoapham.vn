<?php
$json = file_get_contents("php://input");
$obj = json_decode($json, TRUE);
$un = $obj["USERNAME"];
$pa = md5($obj["PASSWORD"]); // thuc te: Nho escapte tranh Injection

require("jwt.php");
require("dbCon.php");

$un = $obj["USERNAME"];
$pa = md5($obj["PASSWORD"]); // thuc te: Nho escapte tranh Injection

$qr = " SELECT * FROM Users
        WHERE Username='$un'
        AND   Password='$pa'
      ";

$users = mysql_query($qr);
if(mysql_num_rows($users)==1){
  //login dung
  $u = mysql_fetch_array($users);
  $token = array();
  $token["id"] = $u["id"];
  $token["Username"] = $u["Username"];
  $token["HoTen"] = $u["HoTen"];
  $token["Email"] = $u["Email"];

  $jsonwebtoken = JWT::encode($token, "DUNG_CHO_AI_BIET_NHA");
  echo JsonHelper::getJson("token", $jsonwebtoken);
}else{
  // login sai
  echo '{"token":"ERROR"}';
}

?>
